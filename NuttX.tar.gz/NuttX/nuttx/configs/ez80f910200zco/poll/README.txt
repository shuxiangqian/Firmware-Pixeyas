README.txt
^^^^^^^^^^

poll.zdsproj is a simple ZDS-II project that will allow you
  to use the ZDS-II debugger.
