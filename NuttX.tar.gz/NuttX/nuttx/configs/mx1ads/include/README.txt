This directory contains header files unique to the Freescale MX1ADS evaluation board.
