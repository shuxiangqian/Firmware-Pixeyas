This directory contains source files unique to the QEMU i486 platform.
